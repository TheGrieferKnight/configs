## What is New in SampleModule 1.0
March 9, 2016

* Note: Due to a bug in `Update-ModuleManifest` you cannot put a single
quote in your release notes.

* Initial release with support for New-File, Import-FileNoWildcard and
Import-FileWildcard commands.

### Feedback
Please send your feedback to http://github.com/____.com/issues